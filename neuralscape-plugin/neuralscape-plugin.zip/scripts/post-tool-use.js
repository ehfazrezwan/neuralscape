#!/usr/bin/env node

// src/utils.ts
var NEURALSCAPE_URL = process.env.NEURALSCAPE_URL?.replace(/\/$/, "") || "http://localhost:8199";
var DEFAULT_USER_ID = process.env.NEURALSCAPE_USER_ID || "ehfaz";
var REQUEST_TIMEOUT_MS = 8e3;
async function parseStdin() {
  return new Promise((resolve) => {
    let data = "";
    process.stdin.setEncoding("utf-8");
    process.stdin.on("data", (chunk) => {
      data += chunk;
    });
    process.stdin.on("end", () => {
      try {
        resolve(JSON.parse(data));
      } catch {
        resolve({});
      }
    });
    if (process.stdin.readableEnded) {
      try {
        resolve(JSON.parse(data));
      } catch {
        resolve({});
      }
    }
  });
}
function getUserId() {
  return DEFAULT_USER_ID;
}
function getProjectId(cwd) {
  const dir = cwd || process.cwd();
  const parts = dir.split("/").filter(Boolean);
  return parts.length > 0 ? parts[parts.length - 1] : void 0;
}
async function neuralscapePost(endpoint, body) {
  const url = `${NEURALSCAPE_URL}${endpoint}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    return await response.json();
  } finally {
    clearTimeout(timeout);
  }
}
function outputHookResult(result) {
  process.stdout.write(JSON.stringify(result));
}
function outputContinue() {
  outputHookResult({ continue: true, suppressOutput: true });
}
function logError(message, error) {
  const errMsg = error instanceof Error ? error.message : String(error || "");
  process.stderr.write(`[neuralscape] ${message}${errMsg ? `: ${errMsg}` : ""}
`);
}

// src/post-tool-use.ts
var TOOL_CATEGORY_MAP = {
  Write: "task_context",
  Edit: "task_context",
  Bash: "task_context",
  WebFetch: "task_context",
  WebSearch: "task_context",
  Task: "task_context",
  NotebookEdit: "task_context"
};
var SKIP_TOOLS = /* @__PURE__ */ new Set([
  "Glob",
  "Grep",
  "Read",
  "AskUserQuestion",
  "ListMcpResourcesTool",
  "ReadMcpResourceTool",
  "TaskList",
  "TaskGet",
  "TaskCreate",
  "TaskUpdate"
]);
var BASH_SKIP_PATTERNS = [
  /^(cat|head|tail|less|more)\s+/,
  /^(ls|ll|find|tree|wc|du|df)\s+/,
  /^(grep|rg|ag|ack)\s+/,
  /^(echo|printf)\s+/,
  /^(git\s+(status|log|diff|show|branch|remote|stash\s+list))/,
  /^(docker\s+(logs|ps|exec|inspect|images))/,
  /^(docker\s+compose\s+(ps|logs|config))/,
  /^(redis-cli|mongo|psql|mysql)\s+/,
  /^curl\s+.*(-s|--silent).*localhost/,
  // Diagnostic curls to local services
  /^(which|where|type|command)\s+/,
  /^(env|printenv|set)\s*$/,
  /^(node|python3?)\s+(-c|--check|-e)\s+/,
  // One-liner scripts
  /^source\s+/,
  /^sleep\s+/
];
function shouldCaptureBashCommand(command) {
  const trimmed = command.trim();
  if (trimmed.length < 3) return false;
  for (const pattern of BASH_SKIP_PATTERNS) {
    if (pattern.test(trimmed)) return false;
  }
  return true;
}
var SKIP_FILE_PATTERNS = [
  /\/node_modules\//,
  /\/__pycache__\//,
  /\.pyc$/,
  /\/\.git\//,
  /package-lock\.json$/,
  /uv\.lock$/,
  /\.log$/
];
function shouldCaptureFilePath(filePath) {
  for (const pattern of SKIP_FILE_PATTERNS) {
    if (pattern.test(filePath)) return false;
  }
  return true;
}
function summarizeTool(input) {
  const toolName = input.tool_name || "unknown";
  const toolInput = input.tool_input || {};
  if (SKIP_TOOLS.has(toolName)) return null;
  switch (toolName) {
    case "Write": {
      const filePath = toolInput.file_path;
      if (!filePath || !shouldCaptureFilePath(filePath)) return null;
      return `Wrote file ${filePath}`;
    }
    case "Edit": {
      const filePath = toolInput.file_path;
      if (!filePath || !shouldCaptureFilePath(filePath)) return null;
      return `Edited file ${filePath}`;
    }
    case "Bash": {
      const command = toolInput.command;
      if (!command || !shouldCaptureBashCommand(command)) return null;
      const shortCmd = command.length > 120 ? command.slice(0, 120) + "..." : command;
      return `Ran command: ${shortCmd}`;
    }
    case "WebFetch": {
      const url = toolInput.url;
      return url ? `Fetched web content from ${url}` : null;
    }
    case "WebSearch": {
      const query = toolInput.query;
      return query ? `Searched web for: ${query}` : null;
    }
    case "Task": {
      const desc = toolInput.description;
      const agentType = toolInput.subagent_type;
      return desc ? `Launched ${agentType || "agent"} task: ${desc}` : null;
    }
    case "NotebookEdit": {
      const notebookPath = toolInput.notebook_path;
      return notebookPath ? `Edited notebook ${notebookPath}` : null;
    }
    default:
      return null;
  }
}
function deriveScope(category, projectId) {
  const projectCategories = /* @__PURE__ */ new Set([
    "tech_stack",
    "convention",
    "architecture",
    "dependency"
  ]);
  if (projectCategories.has(category) && projectId) return "project";
  if (projectId) return "project";
  return "global";
}
async function main() {
  outputContinue();
  try {
    const input = await parseStdin();
    const toolName = input.tool_name;
    if (!toolName || SKIP_TOOLS.has(toolName)) return;
    const summary = summarizeTool(input);
    if (!summary) return;
    const userId = getUserId();
    const projectId = getProjectId(input.cwd);
    const category = TOOL_CATEGORY_MAP[toolName] || "task_context";
    const scope = deriveScope(category, projectId);
    const body = {
      content: summary,
      user_id: userId,
      category,
      scope,
      tags: ["auto_captured", `tool:${toolName}`]
    };
    if (projectId && scope === "project") {
      body.project_id = projectId;
    }
    await neuralscapePost("/v1/memories/raw", body).catch((error) => {
      logError("Failed to store observation", error);
    });
  } catch (error) {
    logError("post-tool-use hook failed", error);
  }
}
main();
