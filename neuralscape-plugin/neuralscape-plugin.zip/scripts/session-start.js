#!/usr/bin/env node

// src/utils.ts
var NEURALSCAPE_URL = process.env.NEURALSCAPE_URL?.replace(/\/$/, "") || "http://localhost:8199";
var DEFAULT_USER_ID = process.env.NEURALSCAPE_USER_ID || "ehfaz";
var REQUEST_TIMEOUT_MS = 8e3;
async function parseStdin() {
  return new Promise((resolve) => {
    let data = "";
    process.stdin.setEncoding("utf-8");
    process.stdin.on("data", (chunk) => {
      data += chunk;
    });
    process.stdin.on("end", () => {
      try {
        resolve(JSON.parse(data));
      } catch {
        resolve({});
      }
    });
    if (process.stdin.readableEnded) {
      try {
        resolve(JSON.parse(data));
      } catch {
        resolve({});
      }
    }
  });
}
function getUserId() {
  return DEFAULT_USER_ID;
}
function getProjectId(cwd) {
  const dir = cwd || process.cwd();
  const parts = dir.split("/").filter(Boolean);
  return parts.length > 0 ? parts[parts.length - 1] : void 0;
}
async function neuralscapeGet(endpoint, params) {
  const url = new URL(`${NEURALSCAPE_URL}${endpoint}`);
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      url.searchParams.set(key, value);
    }
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(url.toString(), {
      method: "GET",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    return await response.json();
  } finally {
    clearTimeout(timeout);
  }
}
function outputHookResult(result) {
  process.stdout.write(JSON.stringify(result));
}
function outputContinue() {
  outputHookResult({ continue: true, suppressOutput: true });
}
function outputWithContext(context, hookEventName = "SessionStart") {
  outputHookResult({
    continue: true,
    hookSpecificOutput: {
      hookEventName,
      additionalContext: context
    }
  });
}
function logError(message, error) {
  const errMsg = error instanceof Error ? error.message : String(error || "");
  process.stderr.write(`[neuralscape] ${message}${errMsg ? `: ${errMsg}` : ""}
`);
}

// src/session-start.ts
var CATEGORY_ORDER = [
  "preference",
  "convention",
  "architecture",
  "tech_stack",
  "dependency",
  "workflow",
  "procedure",
  "decision",
  "personal_fact",
  "technical_skill",
  "domain_knowledge",
  "interaction",
  "task_context"
];
var CATEGORY_LABELS = {
  preference: "Preferences",
  personal_fact: "Personal",
  technical_skill: "Skills",
  domain_knowledge: "Domain Knowledge",
  tech_stack: "Tech Stack",
  convention: "Conventions",
  architecture: "Architecture",
  dependency: "Dependencies",
  decision: "Decisions",
  interaction: "Interactions",
  workflow: "Workflows",
  procedure: "Procedures",
  task_context: "Recent Context"
};
var MAX_CHARS = 8e3;
function formatMemories(categories) {
  const sections = [];
  let totalChars = 0;
  for (const cat of CATEGORY_ORDER) {
    const memories = categories[cat];
    if (!memories || memories.length === 0) continue;
    const label = CATEGORY_LABELS[cat] || cat;
    const lines = [`## ${label}`];
    for (const mem of memories) {
      const line = `- ${mem.memory}`;
      if (totalChars + line.length > MAX_CHARS) break;
      lines.push(line);
      totalChars += line.length;
    }
    if (lines.length > 1) {
      sections.push(lines.join("\n"));
    }
    if (totalChars >= MAX_CHARS) break;
  }
  if (sections.length === 0) return "";
  return `# Neuralscape Memory Context

${sections.join("\n\n")}`;
}
async function main() {
  try {
    const input = await parseStdin();
    const userId = getUserId();
    const projectId = getProjectId(input.cwd);
    let context;
    try {
      if (projectId) {
        context = await neuralscapeGet(`/v1/context/${projectId}`, {
          user_id: userId
        });
      } else {
        context = await neuralscapeGet("/v1/context/global", {
          user_id: userId
        });
      }
    } catch {
      outputContinue();
      return;
    }
    const formatted = formatMemories(context.categories || {});
    if (formatted) {
      outputWithContext(formatted);
    } else {
      outputContinue();
    }
  } catch (error) {
    logError("session-start hook failed", error);
    outputContinue();
  }
}
main();
