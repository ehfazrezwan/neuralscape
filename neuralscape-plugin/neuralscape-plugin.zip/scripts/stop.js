#!/usr/bin/env node

// src/utils.ts
var NEURALSCAPE_URL = process.env.NEURALSCAPE_URL?.replace(/\/$/, "") || "http://localhost:8199";
var DEFAULT_USER_ID = process.env.NEURALSCAPE_USER_ID || "ehfaz";
var REQUEST_TIMEOUT_MS = 8e3;
async function parseStdin() {
  return new Promise((resolve) => {
    let data = "";
    process.stdin.setEncoding("utf-8");
    process.stdin.on("data", (chunk) => {
      data += chunk;
    });
    process.stdin.on("end", () => {
      try {
        resolve(JSON.parse(data));
      } catch {
        resolve({});
      }
    });
    if (process.stdin.readableEnded) {
      try {
        resolve(JSON.parse(data));
      } catch {
        resolve({});
      }
    }
  });
}
function getUserId() {
  return DEFAULT_USER_ID;
}
function getProjectId(cwd) {
  const dir = cwd || process.cwd();
  const parts = dir.split("/").filter(Boolean);
  return parts.length > 0 ? parts[parts.length - 1] : void 0;
}
async function neuralscapePost(endpoint, body) {
  const url = `${NEURALSCAPE_URL}${endpoint}`;
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal
    });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    return await response.json();
  } finally {
    clearTimeout(timeout);
  }
}
function outputHookResult(result) {
  process.stdout.write(JSON.stringify(result));
}
function outputContinue() {
  outputHookResult({ continue: true, suppressOutput: true });
}
function logError(message, error) {
  const errMsg = error instanceof Error ? error.message : String(error || "");
  process.stderr.write(`[neuralscape] ${message}${errMsg ? `: ${errMsg}` : ""}
`);
}

// src/stop.ts
async function main() {
  outputContinue();
  try {
    const input = await parseStdin();
    const userId = getUserId();
    const projectId = getProjectId(input.cwd);
    const sessionId = input.session_id;
    const body = {
      content: `Session ${sessionId || "unknown"} completed in project ${projectId || "unknown"}`,
      user_id: userId,
      category: "interaction",
      scope: projectId ? "project" : "global",
      tags: ["auto_captured", "session_end"]
    };
    if (projectId) {
      body.project_id = projectId;
    }
    await neuralscapePost("/v1/memories/raw", body).catch((error) => {
      logError("Failed to store session marker", error);
    });
  } catch (error) {
    logError("stop hook failed", error);
  }
}
main();
